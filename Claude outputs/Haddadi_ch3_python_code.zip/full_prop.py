"""full_prop.py - Model A (numerical, full dynamics), faster implementation.

Same force model as decay_sim.accel_full (2-body, J2, co-rotating drag with
exponential atmosphere, Sun and Moon third-body, cannonball SRP with cylindrical
shadow). Differences from accel_full, all for speed and documented in the thesis:
  * Sun and Moon positions are tabulated every 1800 s (linear interpolation).
    Position error of the Moon from this interpolation is < 1.5 km, i.e. < 0.01 %
    of the lunar tidal acceleration.
  * Scalar arithmetic in the right-hand side instead of small numpy arrays.
Perigee passages are located exactly with the event function r.v = 0 (not by
sampling), and the lifetime events (r = R_E + 175 km and R_E + 120 km) are terminal.
"""
import math
import time
import numpy as np
from scipy.integrate import solve_ivp
import decay_sim as ds

MU = ds.MU_E
RE = ds.R_E
J2 = ds.J2
WE = ds.W_E
MUS = ds.MU_S
MUM = ds.MU_M
AU = ds.AU
PSR = ds.P_SR
CR = ds.CR
YR_S = 365.25 * 86400.0
TAB_DT = 1800.0
GRID_OK = True


def tables(t_end, jd0=None):
    if jd0 is None:
        jd0 = ds.JD_EPOCH
    n = int(t_end / TAB_DT) + 4
    jd = jd0 + np.arange(n) * TAB_DT / 86400.0
    S = ds.sun_eci(jd).T.tolist()
    M = ds.moon_eci(jd).T.tolist()
    return S, M


def initial_state(hp_km, argp_deg=0.0, raan_deg=0.0, inc_deg=27.0, ha_km=35786.0):
    """Osculating GTO state at perigee. argp_deg = 0 reproduces decay_sim.gto_initial_state."""
    rp = RE + hp_km * 1e3
    ra = RE + ha_km * 1e3
    a = 0.5 * (rp + ra)
    e = (ra - rp) / (ra + rp)
    vp = math.sqrt(MU * (1.0 + e) / rp)
    r_pf = np.array([rp, 0.0, 0.0])
    v_pf = np.array([0.0, vp, 0.0])
    i = math.radians(inc_deg)
    O = math.radians(raan_deg)
    w = math.radians(argp_deg)

    def Rz(t):
        c, s = math.cos(t), math.sin(t)
        return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])

    def Rx(t):
        c, s = math.cos(t), math.sin(t)
        return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])

    R = Rz(O) @ Rx(i) @ Rz(w)
    return np.concatenate([R @ r_pf, R @ v_pf])


def rho_scalar(h_m, f107, ap, T_cache=None):
    h = h_m / 1000.0
    if h < 0.0 or h > 1000.0:
        return 0.0
    hc = min(max(h, 0.0), 1000.0)
    T = 900.0 + 2.5 * (f107 - 70.0) + 1.5 * ap
    H = T / (27.0 - 0.012 * (hc - 200.0))
    return 6e-10 * math.exp(-(hc - 175.0) / H)


def propagate(hp0_km, argp_deg=0.0, a_sail=0.0, sail_factor=1.0, deploy_day=0.0,
               t_max_yr=25.0, f107=130.0, ap=10.0, cd=ds.CD, third=True, srp=True,
               rtol=1e-9, atol_r=1e-3, atol_v=1e-7, stop_km=(175.0, 120.0),
               raan_deg=0.0, jd0=None):
    """Returns dict: peri_t_yr, peri_hp_km (every perigee passage), t_stop_yr {km: years or inf}."""
    t_max = t_max_yr * YR_S
    S, M = tables(t_max, jd0)
    am_nat = ds.composite_am(0.0)
    am_sail = ds.composite_am(a_sail, sail_factor)
    td = deploy_day * 86400.0
    T_atm = 900.0 + 2.5 * (f107 - 70.0) + 1.5 * ap  # constant part of scale height numerator
    k_drag = 0.5 * cd
    j2c = 1.5 * J2 * MU * RE * RE

    def rhs(t, y):
        x, yy, z, vx, vy, vz = y[0], y[1], y[2], y[3], y[4], y[5]
        r2 = x * x + yy * yy + z * z
        rn = math.sqrt(r2)
        r3 = r2 * rn
        r5 = r3 * r2
        ax = -MU * x / r3
        ay = -MU * yy / r3
        az = -MU * z / r3
        kJ = j2c / r5
        z2r2 = z * z / r2
        ax += kJ * x * (5.0 * z2r2 - 1.0)
        ay += kJ * yy * (5.0 * z2r2 - 1.0)
        az += kJ * z * (5.0 * z2r2 - 3.0)
        # drag, co-rotating atmosphere: v_rel = v - w x r, w x r = (-WE*y, WE*x, 0)
        vrx = vx + WE * yy
        vry = vy - WE * x
        vr = math.sqrt(vrx * vrx + vry * vry + vz * vz)
        am = am_nat if t < td else am_sail
        h_m = rn - RE
        if h_m >= 0.0:
            h = h_m / 1000.0
            if h <= 1000.0:
                hc = h if h > 0.0 else 0.0
                Hs = T_atm / (27.0 - 0.012 * (hc - 200.0))
                rho = 6e-10 * math.exp(-(hc - 175.0) / Hs)
                fac = -k_drag * am * rho * vr
                ax += fac * vrx
                ay += fac * vry
                az += fac * vz
        if third or srp:
            idx = t / TAB_DT
            i0 = int(idx)
            f = idx - i0
            s0 = S[i0]
            s1 = S[i0 + 1]
            sx = s0[0] + f * (s1[0] - s0[0])
            sy = s0[1] + f * (s1[1] - s0[1])
            sz = s0[2] + f * (s1[2] - s0[2])
            dx, dy, dz = sx - x, sy - yy, sz - z
            dd = math.sqrt(dx * dx + dy * dy + dz * dz)
            srn = math.sqrt(sx * sx + sy * sy + sz * sz)
            if third:
                c1 = MUS / (dd ** 3)
                c2 = MUS / (srn ** 3)
                ax += c1 * dx - c2 * sx
                ay += c1 * dy - c2 * sy
                az += c1 * dz - c2 * sz
                m0 = M[i0]
                m1 = M[i0 + 1]
                mx = m0[0] + f * (m1[0] - m0[0])
                my = m0[1] + f * (m1[1] - m0[1])
                mz = m0[2] + f * (m1[2] - m0[2])
                ex, ey, ez = mx - x, my - yy, mz - z
                de = math.sqrt(ex * ex + ey * ey + ez * ez)
                mrn = math.sqrt(mx * mx + my * my + mz * mz)
                c3 = MUM / (de ** 3)
                c4 = MUM / (mrn ** 3)
                ax += c3 * ex - c4 * mx
                ay += c3 * ey - c4 * my
                az += c3 * ez - c4 * mz
            if srp:
                # cylindrical Earth shadow, Sun direction from the Sun vector
                proj = x * sx + yy * sy + z * sz
                if proj < 0.0:
                    # perpendicular distance to the Sun-Earth line
                    un = srn
                    ux, uy, uz = sx / un, sy / un, sz / un
                    px = x - proj / (un * un) * sx
                    py = yy - proj / (un * un) * sy
                    pz = z - proj / (un * un) * sz
                    perp = math.sqrt(px * px + py * py + pz * pz)
                    in_sh = perp < RE
                else:
                    in_sh = False
                if not in_sh:
                    P = PSR * (AU / dd) ** 2
                    f_srp = -P * CR * am / dd
                    ax += f_srp * dx
                    ay += f_srp * dy
                    az += f_srp * dz
        return np.array([vx, vy, vz, ax, ay, az])

    def ev_peri(t, y):
        return y[0] * y[3] + y[1] * y[4] + y[2] * y[5]
    ev_peri.direction = 1.0

    evs = [ev_peri]
    for km in (175.0, 120.0):      # always recorded: first inbound crossing of each radius
        rs_ = RE + km * 1e3

        def ev(t, y, rs_=rs_):
            return math.sqrt(y[0] * y[0] + y[1] * y[1] + y[2] * y[2]) - rs_
        ev.terminal = km in stop_km  # integration stops at the first crossing of these radii
        ev.direction = -1.0
        evs.append(ev)

    y0 = initial_state(hp0_km, argp_deg, raan_deg)
    sol = solve_ivp(rhs, (0.0, t_max), y0, method="DOP853", rtol=rtol,
                    atol=np.array([atol_r] * 3 + [atol_v] * 3), events=evs)
    pt = sol.t_events[0]
    pr = np.linalg.norm(sol.y_events[0][:, :3], axis=1) if len(pt) else np.array([])
    keep = pt > 1.0
    peri_t_yr = pt[keep] / YR_S
    peri_hp = (pr[keep] - RE) / 1e3
    t_stop = {}
    for k, km in enumerate((175.0, 120.0)):
        tk = sol.t_events[k + 1]
        t_stop[km] = float(tk[0] / YR_S) if len(tk) else float("inf")
    return dict(peri_t_yr=peri_t_yr, peri_hp_km=peri_hp, t_stop_yr=t_stop, status=sol.status,
                t_end_yr=float(sol.t[-1] / YR_S))


if __name__ == "__main__":
    t0 = time.time()
    out = propagate(250.0, 0.0, t_max_yr=1.0)
    hp = out["peri_hp_km"]
    print("ω=0 natural, 1 yr: passages", hp.size, "first", np.round(hp[:4], 3), "min %.2f max %.2f last %.2f" % (hp.min(), hp.max(), hp[-1]), "stops", out["t_stop_yr"], round(time.time() - t0, 1), "s")
